# Overview

This is a modern full-stack web application for a construction company website, recreating Canada Construction Limited's digital presence. The project features a React frontend with shadcn/ui components, an Express.js backend, and PostgreSQL database integration. The application showcases construction services, company history, service areas, and contact information with a focus on professional presentation and SEO optimization.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens and CSS variables
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state management
- **3D Graphics**: Three.js integration for interactive construction-themed 3D scenes
- **Build Tool**: Vite for fast development and optimized production builds

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Development**: Hot reload with tsx for TypeScript execution
- **Storage Interface**: Abstracted storage layer with in-memory implementation for development
- **API Design**: RESTful API structure with /api prefix routing

## Component Design System
- **Design System**: shadcn/ui "new-york" style variant
- **Typography**: Custom font stack with Montserrat, Open Sans, and system fonts
- **Color Scheme**: Professional construction industry palette with primary blue (#1B365D), secondary orange (#FF6B35), and accent yellow (#FFB347)
- **Responsive Design**: Mobile-first approach with Tailwind breakpoints
- **Component Structure**: Modular sections for hero, services, about, areas, contact, and footer

## Data Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Database**: PostgreSQL with Neon serverless integration
- **Schema**: Type-safe schema definitions with Zod validation
- **Migrations**: Drizzle Kit for database schema management
- **Development Storage**: In-memory storage implementation for rapid prototyping

## Development Workflow
- **Package Manager**: npm with lockfile version 3
- **TypeScript**: Strict configuration with path mapping for clean imports
- **Code Quality**: ESLint integration through Vite plugins
- **Build Process**: Separate client and server builds with esbuild for server bundling

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL hosting (@neondatabase/serverless)
- **Connection Management**: PostgreSQL session store (connect-pg-simple)

## UI Framework Dependencies
- **Radix UI**: Comprehensive set of unstyled, accessible UI primitives
- **Class Variance Authority**: Utility for creating variant-based component APIs
- **Tailwind CSS**: Utility-first CSS framework with custom configuration
- **Lucide React**: Modern icon library for consistent iconography

## Development Tools
- **Vite Plugins**: Runtime error overlay, cartographer, and dev banner for Replit integration
- **React Hook Form**: Form state management with Zod resolver integration
- **TanStack Query**: Powerful data synchronization for React applications

## Third-Party Integrations
- **Three.js**: 3D graphics library loaded via CDN for construction-themed animations
- **Google Fonts**: Montserrat and Open Sans font families for professional typography
- **Unsplash**: Construction imagery for hero section backgrounds

## Build and Deployment
- **PostCSS**: CSS processing with Tailwind and Autoprefixer plugins
- **esbuild**: Fast JavaScript bundler for server-side code
- **TypeScript Compiler**: Type checking and code validation