import { useState, useEffect } from "react";
import { Menu } from "lucide-react";

export default function FloatingNav() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav 
      className={`fixed top-6 left-1/2 transform -translate-x-1/2 z-50 rounded-full px-8 py-4 transition-all duration-300 ${
        isScrolled 
          ? 'floating-nav shadow-lg' 
          : 'bg-transparent'
      }`}
      data-testid="main-navigation"
    >
      <div className="flex items-center space-x-8">
        <div className="font-montserrat font-bold text-primary text-lg" data-testid="logo">
          CCL
        </div>
        <div className="hidden md:flex space-x-6">
          <a 
            href="#home" 
            className="nav-link text-sm font-medium text-foreground hover:text-primary transition-colors"
            data-testid="nav-home"
          >
            Home
          </a>
          <a 
            href="#services" 
            className="nav-link text-sm font-medium text-foreground hover:text-primary transition-colors"
            data-testid="nav-services"
          >
            Services
          </a>
          <a 
            href="#about" 
            className="nav-link text-sm font-medium text-foreground hover:text-primary transition-colors"
            data-testid="nav-about"
          >
            About
          </a>
          <a 
            href="#areas" 
            className="nav-link text-sm font-medium text-foreground hover:text-primary transition-colors"
            data-testid="nav-areas"
          >
            Areas
          </a>
          <a 
            href="#contact" 
            className="nav-link text-sm font-medium text-foreground hover:text-primary transition-colors"
            data-testid="nav-contact"
          >
            Contact
          </a>
        </div>
        <button 
          className="md:hidden text-primary"
          data-testid="mobile-menu-toggle"
        >
          <Menu className="w-5 h-5" />
        </button>
      </div>
    </nav>
  );
}
