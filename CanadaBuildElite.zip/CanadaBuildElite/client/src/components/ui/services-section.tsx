import { Factory, Building, Home, Construction, Wrench, ClipboardList, Check } from "lucide-react";

const services = [
  {
    icon: Factory,
    title: "Industrial Construction",
    description: "Heavy industrial facilities, manufacturing plants, and specialized industrial infrastructure.",
    features: [
      "Manufacturing Facilities",
      "Warehouses & Distribution",
      "Power Plants",
      "Processing Facilities"
    ]
  },
  {
    icon: Building,
    title: "Commercial Construction",
    description: "Office buildings, retail spaces, and mixed-use developments across the Greater Toronto Area.",
    features: [
      "Office Buildings",
      "Retail Centers",
      "Hotels & Hospitality",
      "Mixed-Use Developments"
    ]
  },
  {
    icon: Home,
    title: "Residential Construction",
    description: "Custom homes, condominiums, and residential communities built to the highest standards.",
    features: [
      "Custom Homes",
      "Condominiums",
      "Townhomes",
      "Community Development"
    ]
  },
  {
    icon: Construction,
    title: "Infrastructure",
    description: "Essential infrastructure projects including roads, bridges, and municipal facilities.",
    features: [
      "Roads & Highways",
      "Bridges & Overpasses",
      "Municipal Buildings",
      "Utilities"
    ]
  },
  {
    icon: Wrench,
    title: "Renovation & Restoration",
    description: "Expert renovation and restoration services for existing structures and heritage buildings.",
    features: [
      "Building Restoration",
      "Heritage Preservation",
      "Modernization",
      "Retrofitting"
    ]
  },
  {
    icon: ClipboardList,
    title: "Project Management",
    description: "End-to-end project management ensuring timely delivery and exceptional quality control.",
    features: [
      "Planning & Design",
      "Cost Estimation",
      "Quality Control",
      "Timeline Management"
    ]
  }
];

export default function ServicesSection() {
  return (
    <section id="services" className="py-24 bg-background">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16 section-animate">
          <h2 className="font-montserrat font-bold text-4xl lg:text-5xl text-foreground mb-6">
            Our <span className="text-primary">Services</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Comprehensive construction solutions tailored to meet the unique needs of every project, 
            from concept to completion.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div 
              key={index}
              className="service-card glass-morphism rounded-3xl p-8 text-center hover-lift section-animate"
              data-testid={`service-card-${index}`}
            >
              <div className="service-icon text-5xl text-primary mb-6">
                <service.icon className="w-12 h-12 mx-auto" />
              </div>
              <h3 className="font-montserrat font-bold text-2xl mb-4">{service.title}</h3>
              <p className="text-muted-foreground mb-6">
                {service.description}
              </p>
              <ul className="text-left space-y-2 text-sm">
                {service.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center">
                    <Check className="w-4 h-4 text-accent mr-2" />
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
