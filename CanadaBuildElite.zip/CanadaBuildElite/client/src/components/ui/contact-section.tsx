import { useState } from "react";
import { Phone, Printer, Mail, Briefcase, MapPin, Send } from "lucide-react";
import { Button } from "./button";
import { Input } from "./input";
import { Textarea } from "./textarea";

export default function ContactSection() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    projectType: '',
    details: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement actual form submission
    alert('Thank you for your message! We will get back to you soon.');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <section id="contact" className="py-24 bg-background">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16 section-animate">
          <h2 className="font-montserrat font-bold text-4xl lg:text-5xl text-foreground mb-6">
            Ready to Start Your <span className="text-primary">Project?</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Get in touch with our expert team today. We're here to bring your construction vision to life.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Contact Information */}
          <div className="space-y-8 section-animate">
            <div className="glass-morphism rounded-3xl p-8">
              <h3 className="font-montserrat font-bold text-2xl mb-6">Contact Information</h3>
              
              <div className="space-y-6">
                <div className="flex items-center space-x-4" data-testid="contact-phone">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="font-semibold">Phone</div>
                    <div className="text-muted-foreground">(905) 624-6362</div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4" data-testid="contact-fax">
                  <div className="w-12 h-12 bg-secondary rounded-full flex items-center justify-center text-white">
                    <Printer className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="font-semibold">Printer</div>
                    <div className="text-muted-foreground">(905) 624-6432</div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4" data-testid="contact-email">
                  <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center text-white">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="font-semibold">Email</div>
                    <div className="text-muted-foreground">info@canadaconstructionlimited.ca</div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4" data-testid="contact-careers">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white">
                    <Briefcase className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="font-semibold">Careers</div>
                    <div className="text-muted-foreground">careers@canadaconstructionlimited.ca</div>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4" data-testid="contact-address">
                  <div className="w-12 h-12 bg-secondary rounded-full flex items-center justify-center text-white">
                    <MapPin className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="font-semibold">Office Location</div>
                    <div className="text-muted-foreground">1295 Eglinton Ave E<br />Mississauga, ON</div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Quick Stats */}
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center glass-morphism rounded-2xl p-4">
                <div className="text-2xl font-bold text-primary">24/7</div>
                <div className="text-sm text-muted-foreground">Emergency Support</div>
              </div>
              <div className="text-center glass-morphism rounded-2xl p-4">
                <div className="text-2xl font-bold text-secondary">&lt; 24h</div>
                <div className="text-sm text-muted-foreground">Response Time</div>
              </div>
              <div className="text-center glass-morphism rounded-2xl p-4">
                <div className="text-2xl font-bold text-accent">Free</div>
                <div className="text-sm text-muted-foreground">Consultation</div>
              </div>
            </div>
          </div>
          
          {/* Contact Form */}
          <div className="glass-morphism rounded-3xl p-8 section-animate">
            <h3 className="font-montserrat font-bold text-2xl mb-6">Get A Quote</h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">First Name</label>
                  <Input
                    type="text"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleChange}
                    placeholder="John"
                    className="rounded-xl"
                    data-testid="input-first-name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Last Name</label>
                  <Input
                    type="text"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleChange}
                    placeholder="Doe"
                    className="rounded-xl"
                    data-testid="input-last-name"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Email</label>
                <Input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="john@example.com"
                  className="rounded-xl"
                  data-testid="input-email"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Phone</label>
                <Input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="(555) 123-4567"
                  className="rounded-xl"
                  data-testid="input-phone"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Project Type</label>
                <select 
                  name="projectType"
                  value={formData.projectType}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl border border-input bg-background focus:ring-2 focus:ring-ring focus:border-transparent transition-all"
                  data-testid="select-project-type"
                >
                  <option value="">Select Project Type</option>
                  <option value="industrial">Industrial Construction</option>
                  <option value="commercial">Commercial Construction</option>
                  <option value="residential">Residential Construction</option>
                  <option value="infrastructure">Infrastructure</option>
                  <option value="renovation">Renovation & Restoration</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Project Details</label>
                <Textarea
                  name="details"
                  value={formData.details}
                  onChange={handleChange}
                  rows={4}
                  placeholder="Tell us about your project..."
                  className="rounded-xl"
                  data-testid="textarea-details"
                />
              </div>
              
              <Button 
                type="submit" 
                className="w-full px-8 py-4 rounded-xl font-semibold text-lg"
                data-testid="button-submit"
              >
                <Send className="w-5 h-5 mr-2" />
                Send Message
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
