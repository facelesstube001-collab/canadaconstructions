import { Compass, HardHat, Key, Check } from "lucide-react";

const processes = [
  {
    icon: Compass,
    title: "Planning & Design",
    image: "https://images.unsplash.com/photo-1503387762-592deb58ef4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
    description: "Comprehensive project planning, architectural design, and engineering solutions tailored to your specific requirements and budget.",
    features: [
      "Site Analysis",
      "Architectural Design", 
      "Engineering Plans",
      "Permit Acquisition"
    ]
  },
  {
    icon: HardHat,
    title: "Construction",
    image: "https://images.unsplash.com/photo-1581094794329-c8112a89af12?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
    description: "Expert construction execution using state-of-the-art equipment and proven methodologies to ensure quality and safety at every stage.",
    features: [
      "Foundation Work",
      "Structural Build",
      "Safety Management",
      "Quality Control"
    ]
  },
  {
    icon: Key,
    title: "Delivery & Support",
    image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
    description: "Seamless project handover with ongoing support and maintenance services to ensure your investment continues to deliver value.",
    features: [
      "Final Inspection",
      "Project Handover",
      "Warranty Support",
      "Maintenance Services"
    ]
  }
];

export default function WhatWeDoSection() {
  return (
    <section className="py-24 bg-muted">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16 section-animate">
          <h2 className="font-montserrat font-bold text-4xl lg:text-5xl text-foreground mb-6">
            What We <span className="text-primary">Do</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Our comprehensive approach to construction encompasses every phase of your project, 
            from initial planning to final delivery.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-3 gap-8">
          {processes.map((process, index) => (
            <div 
              key={index}
              className="text-center space-y-6 section-animate"
              data-testid={`process-card-${index}`}
            >
              <img 
                src={process.image} 
                alt={process.title} 
                className="rounded-2xl shadow-lg w-full h-64 object-cover hover-lift" 
              />
              
              <div className="space-y-4">
                <div className={`w-16 h-16 ${index === 0 ? 'bg-primary' : index === 1 ? 'bg-secondary' : 'bg-accent'} rounded-full flex items-center justify-center text-white text-2xl mx-auto`}>
                  <process.icon className="w-8 h-8" />
                </div>
                <h3 className="font-montserrat font-bold text-2xl">{process.title}</h3>
                <p className="text-muted-foreground">
                  {process.description}
                </p>
                <ul className="text-left space-y-2 text-sm max-w-xs mx-auto">
                  {process.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <Check className="w-4 h-4 text-accent mr-2" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
