import { MapPin, Building2, Factory, Home, Phone, CheckCircle } from "lucide-react";
import InteractiveMap from "./interactive-map";

const serviceAreas = [
  {
    icon: Building2,
    name: "Toronto",
    description: "Downtown, North York, Scarborough, Etobicoke",
    color: "primary"
  },
  {
    icon: Factory,
    name: "Mississauga",
    description: "Complete coverage of Mississauga region",
    color: "secondary"
  },
  {
    icon: Factory,
    name: "Markham",
    description: "Richmond Hill, Thornhill, Unionville",
    color: "accent"
  },
  {
    icon: Home,
    name: "Vaughan",
    description: "Woodbridge, Thornhill, Maple",
    color: "primary"
  }
];

const extendedAreas = [
  "Brampton", "Burlington", "Oakville", "Richmond Hill", "Ajax", "Pickering"
];

export default function AreasSection() {
  return (
    <section id="areas" className="py-24 bg-background">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16 section-animate">
          <h2 className="font-montserrat font-bold text-4xl lg:text-5xl text-foreground mb-6">
            Areas We <span className="text-primary">Serve</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Proudly serving communities across the Greater Toronto Area and expanding our reach throughout Ontario.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Interactive Map */}
          <div className="section-animate">
            <InteractiveMap />
          </div>
          
          {/* Service Areas List */}
          <div className="space-y-8 section-animate">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {serviceAreas.map((area, index) => (
                <div 
                  key={index}
                  className="glass-morphism rounded-2xl p-6 hover-lift"
                  data-testid={`area-card-${index}`}
                >
                  <div className="flex items-center space-x-4 mb-4">
                    <div className={`w-12 h-12 bg-${area.color} rounded-full flex items-center justify-center text-white`}>
                      <area.icon className="w-6 h-6" />
                    </div>
                    <h4 className="font-montserrat font-bold text-lg">{area.name}</h4>
                  </div>
                  <p className="text-muted-foreground text-sm">{area.description}</p>
                </div>
              ))}
            </div>
            
            <div className="space-y-4">
              <h4 className="font-montserrat font-bold text-xl">Extended Service Areas</h4>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm text-muted-foreground">
                {extendedAreas.map((area, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-accent" />
                    <span>{area}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <button 
              className="px-8 py-4 bg-primary text-white rounded-full font-semibold text-lg hover:bg-primary/90 transition-all duration-300 hover:scale-105"
              data-testid="button-service-quote"
            >
              <Phone className="inline w-5 h-5 mr-2" />
              Get Service Quote
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
