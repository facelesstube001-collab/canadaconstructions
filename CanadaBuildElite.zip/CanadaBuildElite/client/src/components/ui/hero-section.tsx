import { Award, Phone, Play, ChevronDown } from "lucide-react";
import ThreeScene from "./three-scene";

export default function HeroSection() {
  return (
    <section 
      id="home" 
      className="relative min-h-screen hero-gradient flex items-center justify-center overflow-hidden"
    >
      {/* Background construction site image */}
      <div className="absolute inset-0 opacity-20">
        <img 
          src="https://images.unsplash.com/photo-1541888946425-d81bb19240f5?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&h=1200" 
          alt="Construction site with cranes" 
          className="w-full h-full object-cover" 
        />
      </div>
      
      {/* 3D Container */}
      <div className="hidden lg:block absolute top-1/2 right-[10%] transform -translate-y-1/2 w-[400px] h-[400px] z-10">
        <ThreeScene />
      </div>
      
      {/* Hero Content */}
      <div className="relative z-20 max-w-7xl mx-auto px-6 text-center lg:text-left">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 section-animate">
            <div className="inline-block px-4 py-2 glass-morphism rounded-full text-white text-sm font-medium">
              <Award className="inline w-4 h-4 mr-2 text-accent" />
              Trusted Since 1947
            </div>
            
            <h1 className="font-montserrat font-bold text-5xl lg:text-7xl text-white leading-tight">
              Building Canada's
              <span className="text-accent"> Future</span>
            </h1>
            
            <p className="text-xl text-white/90 max-w-2xl leading-relaxed">
              Premium construction services across industrial, commercial, and residential sectors. 
              Over 75 years of excellence in the Greater Toronto Area and beyond.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <button 
                className="px-8 py-4 bg-secondary text-white rounded-full font-semibold text-lg hover:bg-secondary/90 transition-all duration-300 hover:scale-105 hover:shadow-2xl"
                data-testid="button-call"
              >
                <Phone className="inline w-5 h-5 mr-2" />
                Call (905) 624-6362
              </button>
              <button 
                className="px-8 py-4 glass-morphism text-white rounded-full font-semibold text-lg hover:bg-white/20 transition-all duration-300"
                data-testid="button-watch-story"
              >
                <Play className="inline w-5 h-5 mr-2" />
                Watch Our Story
              </button>
            </div>
            
            <div className="flex items-center space-x-8 pt-8">
              <div className="text-center" data-testid="stat-years">
                <div className="text-3xl font-bold text-accent">75+</div>
                <div className="text-white/80 text-sm">Years Experience</div>
              </div>
              <div className="text-center" data-testid="stat-projects">
                <div className="text-3xl font-bold text-accent">1000+</div>
                <div className="text-white/80 text-sm">Projects Completed</div>
              </div>
              <div className="text-center" data-testid="stat-satisfaction">
                <div className="text-3xl font-bold text-accent">100%</div>
                <div className="text-white/80 text-sm">Client Satisfaction</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white scroll-indicator">
        <div className="flex flex-col items-center space-y-2">
          <span className="text-sm">Scroll to explore</span>
          <ChevronDown className="w-6 h-6" />
        </div>
      </div>
    </section>
  );
}
