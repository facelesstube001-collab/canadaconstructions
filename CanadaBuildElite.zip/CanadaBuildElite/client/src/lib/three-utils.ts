declare global {
  interface Window {
    THREE: any;
  }
}

export function initThreeScene(container: HTMLElement) {
  // Load Three.js from CDN if not already loaded
  if (!window.THREE) {
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';
    script.onload = () => createScene(container);
    document.head.appendChild(script);
  } else {
    createScene(container);
  }
}

function createScene(container: HTMLElement) {
  const THREE = window.THREE;
  
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
  const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
  
  renderer.setSize(400, 400);
  renderer.setClearColor(0x000000, 0);
  container.appendChild(renderer.domElement);

  // Create construction-themed 3D objects
  const geometry1 = new THREE.BoxGeometry(1, 2, 1);
  const material1 = new THREE.MeshPhongMaterial({ 
    color: 0x1B365D,
    transparent: true,
    opacity: 0.8
  });
  const cube1 = new THREE.Mesh(geometry1, material1);
  cube1.position.set(-1, 0, 0);

  const geometry2 = new THREE.CylinderGeometry(0.3, 0.3, 3, 8);
  const material2 = new THREE.MeshPhongMaterial({ 
    color: 0xFF6B35,
    transparent: true,
    opacity: 0.9
  });
  const cylinder = new THREE.Mesh(geometry2, material2);
  cylinder.position.set(1, 0, 0);

  const geometry3 = new THREE.ConeGeometry(0.5, 1, 6);
  const material3 = new THREE.MeshPhongMaterial({ 
    color: 0xF7931E,
    transparent: true,
    opacity: 0.7
  });
  const cone = new THREE.Mesh(geometry3, material3);
  cone.position.set(0, 1.5, 1);

  scene.add(cube1);
  scene.add(cylinder);
  scene.add(cone);

  // Add lighting
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
  scene.add(ambientLight);

  const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
  directionalLight.position.set(10, 10, 5);
  scene.add(directionalLight);

  camera.position.z = 5;

  // Animation loop
  function animate() {
    requestAnimationFrame(animate);

    cube1.rotation.x += 0.01;
    cube1.rotation.y += 0.01;

    cylinder.rotation.z += 0.02;

    cone.rotation.y += 0.015;

    renderer.render(scene, camera);
  }

  animate();
}
